import requests
import time
import ctypes

def set_console_title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

def send_message_to_webhook(webhook_url, message):
    payload = {
        "content": message
    }
    
    try:
        response = requests.post(webhook_url, json=payload)
        response.raise_for_status()
        print("Message sent successfully!")
        return True
    except requests.exceptions.RequestException as e:
        print(f"Error sending message: {e}")
        return False

def main():
    set_console_title("Discord Webhook Spammer") 
    
    webhook_url = input("Enter the webhook URL: ")
    message = input("Enter your message: ")
    count = int(input("How many times do you want to send the message? "))
    delay = float(input("Enter the delay (in seconds) between messages: "))

    successful_sends = 0
    for i in range(count):
        if send_message_to_webhook(webhook_url, message):
            successful_sends += 1
        print(f"Message {i + 1}/{count} sent. Successful: {successful_sends}")
        if i < count - 1:  
            time.sleep(delay)

    print(f"\nFinished. Successfully sent {successful_sends} out of {count} messages.")

if __name__ == "__main__":
    main()