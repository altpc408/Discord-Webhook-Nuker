ONLY run install.bat if you do not have requests installed aka "pip install requests"
AND you must have python for the main.py to be able to be ran.
To install python you can either visit https://python.org or go to Microsoft store and download python from there.
(download the latest python version)